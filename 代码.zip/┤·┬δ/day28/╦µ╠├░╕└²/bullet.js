function Bullet(left,top){
	this.l = null;
	this.t = null;
	this.speed = 2;
	this.img = "image/bullet1.png";
	this.id = null;
	this.left = left;
	this.top = top;
}
Bullet.prototype= {
	constructor:Bullet,
	init:function(){
		//先插入页面然后在去计算图片的位置
		var img = document.createElement("img");
		var _this = this;
		img.src = this.img;
		engine.gameBg.appendChild(img);


		img.onload = function(){
			_this.self = img;
	
			var l =  _this.left - _this.self.offsetWidth/2;
			var t = _this.top - _this.self.offsetHeight;

			_this.self.style.left =l+"px";
			_this.self.style.top =t+"px";

			//更新子弹的位置
			_this.l = l;
			_this.t = t;

			//每创建一个子弹就给当前这个子弹设定一个id值
			_this.id = Math.random();
			engine.bullet[_this.id] = _this;
		}
	},
	move:function(){
		this.speed-=3;
		this.self.style.top = this.t+this.speed+'px';


		if(this.self.offsetTop<=-this.self.offsetHeight){
			this.destory();
		}


		for(var i in engine.enemy){
			if(engine.ispeng(engine.enemy[i].self,this.self)){
				this.destory();
				engine.enemy[i].blood--;

				if(engine.enemy[i].blood==0){
					engine.enemy[i].destory();
				}

			}
		}
	},
	destory:function(){
		this.self.remove();
		delete engine.bullet[this.id];
	}
}