var Hero = {
	HP:3,
	l:null,
	t:null,
	imgs:["image/hero.gif","image/hero-bang.gif"],
	self:null,
	heart:document.getElementById("HP").getElementsByTagName("img"),
	init:function(){
		var img = document.createElement("img");
		img.src=this.imgs[0];
		engine.gameBg.appendChild(img);
		this.self = img;
		this.move();
		this.createBullet();
	},
	move:function(e){
		var _this = this
		document.onmousemove = function(){
			var e = e||event;
			var l = e.clientX - _this.self.offsetWidth/2 - engine.gameBg.offsetLeft;
			var t = e.clientY - _this.self.offsetHeight/2 - engine.gameBg.offsetTop;

			l = l>engine.gameBg.offsetWidth-_this.self.offsetWidth?engine.gameBg.offsetWidth-_this.self.offsetWidth:(l<0?0:l);
			t = t>engine.gameBg.offsetHeight-_this.self.offsetHeight?engine.gameBg.offsetHeight-_this.self.offsetHeight:(t<0?0:t);

			_this.self.style.left = l+'px';
			_this.self.style.top = t+'px';

			//更新this.l 和this.t的值
			_this.l = l;
			_this.t = t;
		}
	},
	createBullet:function(){
		var _this = this;
		setInterval(function(){
			var l = _this.l+_this.self.offsetWidth/2;

			new Bullet(l,_this.t).init();

		},200)
	},
	dei:function(){
		this.HP--;
		if(this.HP>=0){
			this.heart[0].remove();
			if(this.heart.length==0){
				this.destory();
			}
		}
		
	},
	boom:function(){
		var img = document.createElement("img");
		var _this = this;
		img.src = this.imgs[1];
		this.self = img;
		engine.gameBg.appendChild(img);


		this.self.style.left = this.l+'px';
		this.self.style.top = this.t+'px';


		setTimeout(function(){
			_this.self.remove();
			alert("游戏结束");
			location.reload(true);
		},1000)
	},
	destory:function(){
		this.self.remove();
		this.boom();
		
	}
}

