function SmallEnemy(blood,imgs,speed,score){
	var s = parseInt(3+Math.random()*3);
	Enemy.call(this,1,["image/enemy1.png","image/enemy1-bang.gif"],s,1);
}

SmallEnemy.prototype = {
	constructor:SmallEnemy,
	__proto__:Enemy.prototype
}


function MiddleEnemy(blood,imgs,speed,score){
	var s = parseInt(2+Math.random()*3);
	Enemy.call(this,5,["image/enemy2.png","image/enemy2-bang.gif"],s,5);
}

MiddleEnemy.prototype = {
	constructor:MiddleEnemy,
	__proto__:Enemy.prototype
}	


function BigEnemy(blood,imgs,speed,score){
	var s = parseInt(1+Math.random()*2);
	Enemy.call(this,10,["image/enemy3.png","image/enemy3-bang.gif"],s,10);
}

BigEnemy.prototype = {
	constructor:BigEnemy,
	__proto__:Enemy.prototype
}		