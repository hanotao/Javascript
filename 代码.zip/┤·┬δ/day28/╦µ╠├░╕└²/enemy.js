function Enemy(blood,imgs,speed,score){
	this.l = null;
	this.t = null;
	this.id = null;
	this.self = null;
	this.blood = blood;
	this.imgs = imgs;
	this.speed = speed;
	this.score = score;
}
Enemy.prototype= {
	constructor:Enemy,
	init:function(){
		//先插入页面然后在去计算图片的位置
		var img = document.createElement("img");
		var _this = this;
		img.src = this.imgs[0];
		engine.gameBg.appendChild(img);


		img.onload = function(){
			_this.self = img;
	
			var l = parseInt(Math.random()*(320-_this.self.offsetWidth));
			var t =  - _this.self.offsetHeight;

			_this.self.style.left =l+"px";
			_this.self.style.top =t+"px";

			//更新敌机的位置
			_this.l = l;
			_this.t = t;

			//每创建一个敌机就给当前这个敌机设定一个id值
			_this.id = Math.random();
			engine.enemy[_this.id] = _this;
		}
	},
	move:function(){
		
	/*	this.t +=this.speed*/
		this.self.offsetTop+=this.speed
		this.self.style.top = this.self.offsetTop+'px';
		//this.sele.offsetTop?为什么不能用

		if(this.t>=568+this.self.offsetHeight){
			this.destory();
		}

		if(engine.ispeng(this.self,Hero.self)){
			this.destory();
			Hero.dei()

		}
	},
	boom:function(){
		var img = document.createElement("img");
		var _this = this;
		img.src = this.imgs[1];
		this.self = img;
		engine.gameBg.appendChild(img);


		this.self.style.left = this.l+'px';
		this.self.style.top = this.t+'px';


		setTimeout(function(){
			_this.self.remove();
		},1000)
	},
	destory:function(){
		this.self.remove();
		this.boom();
		delete engine.enemy[this.id];
		engine.updateScore(this.score);
	}
}