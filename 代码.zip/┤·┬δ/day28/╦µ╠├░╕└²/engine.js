var engine = {
	gameStatus:false,
	gameBg:document.getElementById("game"),
	score:document.querySelector(".score>span"),
	//将所有敌机放在这个对象里面
	enemy:{},
	//将所有的子弹都放在这个对象里面
	bullet:{},
	init:function() {
		this.start(); 
	},
	start:function(){
		var _this = this;
		this.gameBg.onclick = function(){
			if(!_this.gameStatus){
				_this.gameStatus = true;
				_this.bgmove();
				Hero.init();
				_this.move();
				_this.createEnemy();
			}
		}
	},
	bgmove:function(){
		var _this = this;
		var speed = 0;
		setInterval(function(){
			speed+=3
			_this.gameBg.style["background-position-y"] = speed+'px';
		},30)
	},
	move:function(){
		var _this  = this;
		setInterval(function(){
			for(var i in _this.bullet){
				_this.bullet[i].move();
			}

			for(var i in _this.enemy){
				_this.enemy[i].move();
			}
		},30)
	},
	createEnemy:function(){
		setInterval(function(){
			var n = parseInt(1+Math.random()*15);
			switch (n) {
				case 1:
				case 3:
				case 5:
				case 7:
					//创建小飞机
					new SmallEnemy().init();
					break;
				case 2:
				case 4:
				case 6:
				//创建中型飞机
					new MiddleEnemy().init()
					break;
				case 10:
					//创建大飞机
					new BigEnemy().init();
					break;
			}
		},500)
	},
	ispeng:function(obj1,obj2){
		var l1 = obj1.offsetLeft>obj2.offsetLeft+obj2.offsetWidth;
		var l2 = obj2.offsetLeft>obj1.offsetLeft+obj1.offsetWidth;
		var t1 = obj1.offsetTop>obj2.offsetTop+obj2.offsetHeight;
		var t2 = obj2.offsetTop>obj1.offsetTop+obj1.offsetHeight;

		if(l1 || l2 || t1 || t2){
			return false;
		}else{
			return true;
		}
	},
	updateScore:function(score){
		this.score.innerHTML = Number(this.score.innerHTML)+score
	}

}
engine.init();