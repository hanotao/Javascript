<?php
	header("content-type:text/html;charset=utf-8");
	$num = 2;
	if($num>5){
		echo "大于"."<br/>";
	}else{
		echo "小于"."<br/>";
	}


	switch($num){
		case 1:
			echo "今天星期一";
			break;
		case 2:
			echo "今天星期二";
			break;
		case 3:
			echo "今天星期三";
			break;
		default:
				echo "请正确输入";
	}
?>