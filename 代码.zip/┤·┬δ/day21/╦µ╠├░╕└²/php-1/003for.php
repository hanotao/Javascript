<?php
	header("content-type:text/html;charset=utf-8");

	for($i = 0;$i<10;$i++){
		echo $i."<br/>";
	}
	$i = 0;
	while($i<10){
		echo $i;
		$i++;
	}


	//foreach
?>