<?php
	header("content-type:text/html;charset=utf8");
	//public:公开的属性和方法
	class Person{
		public $name="陈亮";
		public function fn(){
			echo $this->name;
		}
	}


	$chenlian = new Person();

	$chenlian->fn();

	//类就相当于一个模型  类似js里面的构造函数
?>