<?php
	header("content-type:text/html;charset=utf-8");



	function fn($a){
		echo $a;
	}
	fn("陈亮");

?>