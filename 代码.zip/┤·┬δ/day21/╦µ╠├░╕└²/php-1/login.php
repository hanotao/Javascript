<?php
	header("content-type:text/html;charset=utf8");
	$uname = $_REQUEST["username"];
	$upwd = $_REQUEST["password"];


	$data = array(
		array(
			"name"=>"雄辉",
			"pwd"=>"12345"
		),
		array(
			"name"=>"chenliang",
			"pwd"=>"98765"
		),
		array(
			"name"=>"guoyun",
			"pwd"=>"aabbcc"
		),
	);

	$bStop = false;
	foreach($data as $key=>$arr){
		foreach ($arr as $key=>$val ) {
			if($uname == $arr["name"] && $upwd == $arr["pwd"]){
				echo "<script>alert('登录成功')</script>";
				$bStop = true;
				break;
			}
		}
	}

	if(!$bStop){
		echo "<script>alert('用户名或密码错误')</script>";
	}

?>