<?php
	header("content-type:text/html;charset=utf8");
	$uname = $_POST["username"];
	echo strip_tags($uname);
?>