<?php
	//设这头部信息  返回的是一个html文件  编码格式是utf8;
	header("Content-Type: text/html; charset=utf-8");
	$name = "陈亮";


	echo $name."<br/>";
	echo "<h1>我的名字叫</h1>".$name;
?>