<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<style>
		*{margin:0;padding:0;font-size: 12px;}
		.content{width:960px;margin:30px auto;}
		.content dl{float:left;width:33%;margin-bottom: 10px;}
		.content dl dt,.content dl dd{float: left;}
		.content dl dd{margin-left: 10px;}
		.content dl dd p:nth-child(2){margin-top: 10px;}
		.content dl dd p:nth-child(3){margin-top: 40px;color:#c2c2c2;}
	</style>
</head>
<body>
	<?php
		require("data.php");
	?>
	<div class="content">

		<?php
			foreach($data as $key=>$val){
				echo "<dl>
						<dt>
							<img src={$val['img']}>
						</dt>
						<dd>
							<p>{$val['name']}</p>
							<p>{$val['status']}</p>
							<p>{$val['author']}</p>
							<p>{$val['home']}</p>
						</dd>
					</dl>";
			}

		?>
		<!-- 
			require():引入数据

			php中数据的加载需要放在{}


		 -->
		<!-- <dl>
			<dt>
				<img src="images/1.jpg"/>
			</dt>
			<dd>
				<p>玄界天气预报</p>
				<p>怀揣着手机降临在这新世界</p>
				<p>孔长升</p>
			</dd>
		</dl>  --> 
	</div>
</body>
</html>