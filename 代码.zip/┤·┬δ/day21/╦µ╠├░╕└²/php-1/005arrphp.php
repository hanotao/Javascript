<?php
	header("content-type:text/html;charset=utf-8");

	$arr = array(10,20,30,40,50);

	for($i=0;$i<count($arr);$i++){
		echo $arr[$i]."<br/>";
	}

	$data = array("name"=>"陈亮","age"=>30,"sex"=>"女");


	foreach($data as $key=>$val){
		echo $key."<br/>".$val."<br/>";
	}


	echo "<hr/>";

	$newArr = array(
		array(
			"name" => "陈亮",
			"age" => 33
		),
		array(
			"name" => "雄辉",
			"age" => 18	
		),
		array(
			"name" => "伍东妮",
			"age" => 17
		),
		array(
			"name" => "郭云",
			"age" => 16
		)
	);

	// foreach($newArr as $key=>$val){
	// 	foreach($val as $key=>$val){
	// 		echo $val."<br/>";
	// 	}
	// }
	
	echo json_encode($newArr);
	$json = json_encode($newArr);

	print_r(json_decode($json))
?>