<?php
	//引入公共的文件
	include "public.php";

	//接受客户端传递的数据
	$uname = $_REQUEST["username"];
	$upwd = $_REQUEST["password"];


	//编写sql语句
	$sql = "insert into `users` (uname,upwd) values ('$uname','$upwd')";

	//执行sql语句  参数1连接数据库的返回值  参数2：sql语句
	$rows = mysqli_query($conn,$sql);//增删改  返回值都是受影响的行数

	if($rows){
		echo "<script>alert('注册成功');location.href='login.html'</script>";
	}else{
		echo "<script>alert('注册失败');location.href='register.html'</script>";
	}

?>