<a href="add.html">增加学生成绩</a>
<?php
	include "public.php";

	//编写sql语句
	$sql = "select * from `score`";

	//执行sql语句
	$res = mysqli_query($conn,$sql);//结果集

	echo "<table border=1>
			<tr>
				<td>编号</td>
				<td>姓名</td>
				<td>h5</td>
				<td>js</td>
				<td>操作</td>
			</tr>";

   while($arr =mysqli_fetch_assoc($res)){
   		echo "<tr>
				<td>{$arr['sid']}</td>
				<td>{$arr['sname']}</td>
				<td>{$arr['sh5']}</td>
				<td>{$arr['sjs']}</td>
				<td><a href='del.php?id={$arr['sid']}'>删除</a><a href='updata.php?id={$arr['sid']}'>修改</a></td>
   			</tr>";
   }

	echo "</table>";

?>