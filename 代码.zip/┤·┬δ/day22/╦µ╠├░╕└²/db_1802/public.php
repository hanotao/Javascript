<?php
	//第一件事情连接数据库
	header("content-type:text/html;charset=utf8");
	//服务器地址
	$db_hostname = "localhost";

	//用户名
	$db_username = "root";

	//密码
	$db_password = "root";

	//数据库的名称
	$db_name = "db_1802";

	//连接数据库
	$conn = new mysqli($db_hostname,$db_username,$db_password,$db_name);

	//如果连接失败的话那么就告诉客户端  连接失败 并且终止这个程序
	if($conn->connect_error){
		die("连接失败".$conn->connect_error);
	}

	//设置数据库的编码格式
	$conn->query("set names utf8");
?>