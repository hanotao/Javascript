<?php
	include "public.php";

	$uname = $_REQUEST["username"];
	$upwd = $_REQUEST["password"];

	//编写sql语句
	$sql = "select * from `users` where uname='$uname'";

	//执行sql语句
	$res = mysqli_query($conn,$sql);//查的返回值是一个结果集

	//查看结果集中有多少条数据
	$n = mysqli_num_rows($res);

	//判断
	if(!$n){
		echo "<script>alert('用户名不存在');location.href='login.html';</script>";
	}else{

		//如何从结果集中取出数据--注意：每次只能取出一条数据
		$data = mysqli_fetch_assoc($res);

		if($data["uname"] ==$uname && $data["upwd"] ==$upwd){
			echo "<script>alert('登录成功');location.href='score.php'</script>";
		}else{
			echo "<script>alert('密码错误');location.href='login.html';</script>";
		}
	}
?>