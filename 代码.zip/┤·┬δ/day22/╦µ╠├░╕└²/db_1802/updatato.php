<?php
	include "public.php";

	$id = $_REQUEST["id"];
	$uname = $_REQUEST["username"];
	$sh5 = $_REQUEST["h5"];
	$sjs = $_REQUEST["js"];

	$sql = "update `score` set sname='$uname',sh5=$sh5,sjs=$sjs where sid=$id";

	$rows = mysqli_query($conn,$sql);//受影响的行数;

	if($rows){
		echo "<script>alert('修改成功');location.href='score.php';</script>";
	}else{
		echo "<script>alert('修改失败');location.href='updata.php';</script>";

	}
?>