<?php

	header("content-type:text/html;charset=utf8");
	$db_hostname = "localhost";

	$db_username = "root";

	$db_password = "root";

	//连接数据库
	$conn = new mysqli($db_hostname,$db_username,$db_password);

	//当服务器连接错误的时候应该去做什么事情
	if($conn->connect_error){
		//告诉客户端连接失败 并且推出当前服务器
		die("连接失败".$conn->connect_error);
	}

	echo "连接成功";
?>