<?php
	include "public.php";

	$uname = $_REQUEST["username"];
	$h5 = $_REQUEST["h5"];
	$js = $_REQUEST["js"];

	//编写sql语句
	$sql = "insert into `score` (sname,sh5,sjs) values ('$uname',$h5,$js)";

	//执行sql语句
	$rows = mysqli_query($conn,$sql);//受影响的行数

	if($rows){
		echo "<script>alert('添加成功');location.href='score.php';</script>";
	}else{
		echo "<script>alert('添加失败');location.href='add.html';</script>";
	}
?>