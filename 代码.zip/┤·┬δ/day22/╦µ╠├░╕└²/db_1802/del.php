<?php
	include "public.php";

	$id = $_GET["id"];

	$sql = "delete from `score` where sid=$id";

	$rows = mysqli_query($conn,$sql);

	if($rows){
		echo "<script>alert('删除成功');location.href='score.php';</script>";
	}else{
		echo "<script>alert('删除失败');location.href='score.php';</script>";
	}
?>