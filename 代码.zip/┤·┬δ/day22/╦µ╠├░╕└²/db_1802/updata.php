<?php
	include "public.php";

	$id = $_GET["id"];

	$sql = "select * from `score` where sid=$id";

	$res = mysqli_query($conn,$sql);

	$data = mysqli_fetch_assoc($res);


?>
<form action="updatato.php" method="post">
	<input type="hidden" name="id" value=<?php
		echo $data['sid'];
	?>>
	<label for="username">学生姓名</label><input type="text" name="username" id="username" value=<?php
		echo $data['sname']
	?>><br/>
	<label for="h5">H5成绩</label><input type="text" name="h5" id="h5" value=<?php
		echo $data['sh5']
	?>><br/>
	<label for="js">JS成绩</label><input type="text" name="js" id="js" value=<?php
		echo $data['sjs']
	?>><br/>
	<input type="submit" value="修改学生成绩">
</form>