/*
随机数

参数：n,m 都是数字

 */
function numRandom(n,m){
	return parseInt(n+Math.random()*(m-n+1));
}

//冒泡排序
function bubble(arr){
	var temp;
	for(var i=0;i<arr.length-1;i++){	
		for(var j=0;j<arr.length-i-1;j++){

			if(arr[j]>arr[j+1]){
				temp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp;
			}
		}
	}
	return arr;
}
//选择排序
function selectSort(arr){
	var temp;
	for(var i=0;i<arr.length-1;i++){
		for(var j=i+1;j<arr.length;j++){
			if(arr[i]>arr[j]){
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}
	return arr;
}

//随机颜色rgb
function colorRandom(){
	var r = numRandom(0,255)
	var g = numRandom(0,255)
	var b = numRandom(0,255)

	return "rgb("+r+","+g+","+b+")"

}

//随机颜色2
function colorT2Random(){
		var r = numRandom(0,255)
		var g = numRandom(0,255)
		var b = numRandom(0,255)
		
		return "#"+insertZero(r,g,b);
	}

	function insertZero(R,G,B){
		R = R.toString(16).length>=2?R.toString(16):"0"+R.toString(16)
		G = G.toString(16).length>=2?G.toString(16):"0"+G.toString(16)
		B = B.toString(16).length>=2?B.toString(16):"0"+B.toString(16)
		
		return R+G+B
	}
//获取子节点
	function chdnod (ele) {	
	var child=ele.childNodes;
	var newchild=[];
	for (i=0;i<child.length;i++) {
		if(child[i].nodeType==1){
			newchild.push(child[i]);
		}
	}
	return newchild;
	}
//获取第一个子节点	
	function fristcd (ele) {	
	var fd=ele.childNodes;		
		for (i=0;i<fd.length;i++) {
			if(fd[i].nodeType==1){
				return fd[i];
			}
		}	
	}
//获取最后一个子节点
function lastcd (ele) {	
	var fd=ele.childNodes;		
	for (i=0;i<fd.length;i++) {
		if(fd[fd.length-i-1].nodeType==1){
			return fd[fd.length-i-1];
		}
	}	
}
//获取上一个子节点
function upcd (ele) {	
	var upcd=ele.previousSibling;			
	for (i=1;i>0;i++) {
		if(upcd.nodeType==1){
			return upcd;
		}else{			 
			 upcd=upcd.previousSibling			 
		}
	}	
}
//获取下一个子节点
function downcd (ele) {	
	var downcd=ele.nextSibling;			
	for (i=1;i>0;i++) {
		if(downcd.nodeType==1){
			return downcd;
		}else{			 
			 downcd=downcd.nextSibling;		 
		}
	}	
}
//获取获取元素到body的距离
function offsetL(ele) {		
	var eleL=ele.offsetLeft;
	while(ele.offsetParent){
		ele=ele.offsetParent;
		eleL+=ele.offsetLeft;
	}
	return eleL;
}