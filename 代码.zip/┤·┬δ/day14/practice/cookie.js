function getCookie(name){
    var cookie = document.cookie;
    var arr = cookie.split("; ");
    for(var i=0;i<arr.length;i++){
        var newArr = arr[i].split("=");
        if(name == newArr[0]){
            return newArr[1];
        }
    }

}


function setCookie(_name,val,expires){
    var d = new Date();
    d.setDate(d.getDate()+expires);
    console.log(d)
    document.cookie = _name+"="+val+";path=/;expires="+d;
}

function removeCookie(_name,val){
    setCookie(_name,val,-1);
}