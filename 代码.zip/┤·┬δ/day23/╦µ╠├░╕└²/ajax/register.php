<?php
	header("content-type:text/html;charset=utf8");

	$db_hostname = "localhost";

	$db_username = "root";

	$db_password = "root";

	$db_name="db_1802";

	$conn = new mysqli($db_hostname,$db_username,$db_password,$db_name);

	if($conn->connect_error){
		die("连接失败".$conn->connect_error);
	}

	$conn->query("set names utf8");

	$uname = $_REQUEST["uname"];
	$upwd = $_REQUEST["upwd"];


	$sql = "insert into `users` (uname,upwd) values ('$uname','$upwd')";

	$rows = mysqli_query($conn,$sql);//受影响的行数
	//后端要返回给前端的是一个json对象
	if($rows){
		echo json_encode(array(
			"status"=>1,
			"info"=>"成功"
		));
	}else{
		echo json_encode(array(
			"status"=>0,
			"info"=>"失败"
		));
	}
?>