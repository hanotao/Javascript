function fn () {
	alert(1)
}