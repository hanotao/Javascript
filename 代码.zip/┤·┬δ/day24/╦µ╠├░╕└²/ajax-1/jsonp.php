<?php
	
	$fn = $_GET["callback"];

	$arr = array(
		"status"=>1,
		"info"=>"测试"
	);

	$data = json_encode($arr);

	echo $fn."(".$data.")";
		


?>