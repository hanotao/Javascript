function fn(){
	alert(1)
}
fn()